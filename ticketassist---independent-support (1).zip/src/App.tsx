/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Phone, 
  Mail, 
  CheckCircle2, 
  HelpCircle, 
  Clock, 
  ShieldCheck, 
  MessageSquare, 
  ArrowRight,
  Info,
  Menu,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const Navbar = ({ onHomeClick }: { onHomeClick?: () => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-blue-600 border-b border-blue-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <button onClick={onHomeClick} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
              <ShieldCheck className="text-blue-600 w-5 h-5" />
            </div>
            <span className="font-bold text-xl tracking-tight text-white">TicketAssist</span>
          </button>
          
          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#services" className="text-sm font-medium text-blue-50 hover:text-white transition-colors">Services</a>
            <a href="#how-it-works" className="text-sm font-medium text-blue-50 hover:text-white transition-colors">How It Works</a>
            <a href="#contact" className="text-sm font-medium text-blue-50 hover:text-white transition-colors">Contact</a>
            <a href="tel:+18334417141" className="flex items-center gap-2 bg-white text-blue-600 px-4 py-2 rounded-full text-sm font-medium hover:bg-blue-50 transition-all">
              <Phone size={16} />
              1-833-441-7141
            </a>
          </div>

          {/* Mobile Actions */}
          <div className="flex md:hidden items-center gap-2">
            <a href="tel:+18334417141" className="flex items-center gap-1 bg-white/10 px-2 py-1 rounded-full text-white border border-white/20 shadow-sm text-[10px] font-bold whitespace-nowrap" aria-label="Call Support">
              <Phone size={12} />
              1-833-441-7141
            </a>
            <button onClick={() => setIsOpen(!isOpen)} className="p-1 text-white">
              {isOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-blue-600 border-b border-blue-500 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-4">
              <a href="#services" onClick={() => setIsOpen(false)} className="block text-base font-medium text-blue-50 hover:text-white">Services</a>
              <a href="#how-it-works" onClick={() => setIsOpen(false)} className="block text-base font-medium text-blue-50 hover:text-white">How It Works</a>
              <a href="#contact" onClick={() => setIsOpen(false)} className="block text-base font-medium text-blue-50 hover:text-white">Contact</a>
              <a href="tel:+18334417141" className="flex items-center gap-2 text-white font-bold">
                <Phone size={18} />
                1-833-441-7141
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const SectionHeading = ({ children, subtitle }: { children: React.ReactNode, subtitle?: string }) => (
  <div className="text-center mb-12">
    <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-4">{children}</h2>
    {subtitle && <p className="text-lg text-slate-400 max-w-2xl mx-auto">{subtitle}</p>}
  </div>
);

export default function App() {
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [showAbout, setShowAbout] = useState(false);

  const celebrityImagesRow1 = [
    "https://i.ibb.co/ksg88TjC/e3accc9fe191b0fb626ca643898de335.jpg",
    "https://i.ibb.co/0jLgRJTF/4ca8906917a87c3c1049035f2dbfbb3b.jpg",
    "https://i.ibb.co/275r03Rc/433a1dd1bd8b89101c54e96333988df9.jpg",
    "https://i.ibb.co/bM4Hrk7c/3f9eab77727ee2ad1821f9df02938423.jpg",
    "https://i.pinimg.com/736x/47/93/6e/47936e7b1162f4aa73abbf9bea71cee0.jpg",
    "https://i.ibb.co/nsVtghfb/37d8e7fc3ecfdef682aef44d4c025264.jpg"
  ];
  const celebrityImagesRow2 = [
    "https://i.ibb.co/qF2H6dJL/bfbbb2f8e9b8212c9b2b87d0a25c0fc8.jpg",
    "https://i.ibb.co/8Lqt7K7r/8003369b2e9c7e1d923986833ec090fa.jpg",
    "https://i.ibb.co/8gB1vkyP/9411bbf53f68c6db841b54ace7e86b5d.jpg",
    "https://i.ibb.co/3mLmKhxf/779bc833a3e2a117eb6d43a33a131ffd.jpg",
    "https://i.ibb.co/jkX4KL0c/14d78a1433cd654571666611b80eb8b2.jpg",
    "https://i.ibb.co/N6nQsGs0/2b9ae080b87d133e05b9f7195a7833a0.jpg"
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    setTimeout(() => setFormStatus('success'), 1500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <Navbar onHomeClick={() => setShowAbout(false)} />

      <main className="flex-grow">
        {showAbout ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="py-20 lg:py-32 bg-slate-950 text-white"
          >
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <div className="w-20 h-20 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-xl shadow-blue-900/20">
                <Info size={40} className="text-white" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-8 tracking-tight">
                Independent Concert & Event Ticket Assistance – 24/7 Support
              </h1>
              <div className="h-1 w-20 bg-blue-600 mx-auto mb-12 rounded-full"></div>
              <p className="text-xl text-slate-400 leading-relaxed mb-12">
                We are dedicated to providing professional, transparent, and reliable support for all your event ticketing needs. Our mission is to empower fans with the information they need to navigate the complex ticketing landscape.
              </p>
              <button 
                onClick={() => setShowAbout(false)}
                className="inline-flex items-center justify-center px-8 py-4 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-900/40"
              >
                Back to Home
              </button>
            </div>
          </motion.div>
        ) : (
          <>
            {/* Hero Section */}
        <section className="relative py-20 lg:py-32 overflow-hidden bg-slate-900 text-white">
          {/* Background Image with Overlay */}
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80&w=2000" 
              alt="Concert background" 
              className="w-full h-full object-cover opacity-40"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/80 to-transparent"></div>
          </div>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-white text-xs font-bold uppercase tracking-wider mb-6 backdrop-blur-sm">
                  <Info size={14} />
                  Independent Support Provider
                </div>
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white mb-6 leading-[1.1]">
                  Independent Concert & Event Ticket Assistance – <span className="text-blue-400">24/7 Support</span>
                </h1>
                <p className="text-xl text-slate-300 mb-8 leading-relaxed max-w-xl">
                  We provide expert guidance and informational support for your ticketing inquiries. Our team helps you navigate the complexities of event access and booking processes.
                </p>
                
                <div className="bg-white/10 border-l-4 border-blue-500 p-4 mb-8 rounded-r-lg backdrop-blur-md">
                  <p className="text-sm text-blue-50 font-medium">
                    <strong>Notice:</strong> We are an independent third-party assistance provider. We are NOT affiliated with, authorized by, or associated with any official ticketing companies, venues, or event organizers.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <a href="#contact" className="inline-flex items-center justify-center px-8 py-4 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-900/40">
                    Get Assistance Now
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </a>
                  <div className="flex flex-col justify-center">
                    <a href="tel:+18334417141" className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors">
                      <Phone size={18} />
                      <span className="font-medium">1-833-441-7141</span>
                    </a>
                  </div>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="hidden lg:block relative"
              >
                <div className="relative z-10 glass-card p-8 bg-white/10 border-white/20 backdrop-blur-xl">
                  <div className="space-y-6">
                    {[
                      { icon: HelpCircle, text: "Booking Guidance" },
                      { icon: ShieldCheck, text: "Cancellation Help" },
                      { icon: Clock, text: "24/7 Availability" }
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-4 p-4 bg-white/10 backdrop-blur-md rounded-xl shadow-sm border border-white/10">
                        <div className="w-10 h-10 bg-blue-600/50 rounded-lg flex items-center justify-center text-white">
                          <item.icon size={20} />
                        </div>
                        <span className="font-semibold text-white">{item.text}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Celebrities and Our Service Section */}
        <section className="py-12 overflow-hidden bg-slate-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
            <SectionHeading subtitle="Providing guidance for the world's most anticipated events and high-profile attendees.">
              Celebrities and Our Service
            </SectionHeading>
          </div>
          
          <div className="space-y-4">
            {/* Row 1: Scrolling Left */}
            <div className="flex overflow-hidden">
              <motion.div 
                animate={{ x: ["0%", "-50%"] }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="flex gap-3 sm:gap-4 pr-3 sm:pr-4"
              >
                {[...celebrityImagesRow1, ...celebrityImagesRow1].map((url, i) => (
                  <div key={i} className="w-40 h-56 sm:w-56 sm:h-72 flex-shrink-0 rounded-xl overflow-hidden border border-slate-800 group relative">
                    <img 
                      src={url} 
                      alt="Event" 
                      className="w-full h-full object-cover transition-all duration-700 scale-110 group-hover:scale-100"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-3 sm:p-4">
                      <span className="text-white text-xs sm:text-sm font-bold tracking-tight">Premium Guidance</span>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>

            {/* Row 2: Scrolling Right */}
            <div className="flex overflow-hidden">
              <motion.div 
                animate={{ x: ["-50%", "0%"] }}
                transition={{ duration: 35, repeat: Infinity, ease: "linear" }}
                className="flex gap-3 sm:gap-4 pr-3 sm:pr-4"
              >
                {[...celebrityImagesRow2, ...celebrityImagesRow2].map((url, i) => (
                  <div key={i} className="w-40 h-56 sm:w-56 sm:h-72 flex-shrink-0 rounded-xl overflow-hidden border border-slate-800 group relative">
                    <img 
                      src={url} 
                      alt="Event" 
                      className="w-full h-full object-cover transition-all duration-700 scale-110 group-hover:scale-100"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-3 sm:p-4">
                      <span className="text-white text-xs sm:text-sm font-bold tracking-tight">Expert Support</span>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-20 bg-slate-900/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading subtitle="We offer informational guidance to help you manage your event attendance effectively.">
              Our Assistance Services
            </SectionHeading>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { title: "Booking Guidance", desc: "via customer support" },
                { title: "Cancellation Assistance", desc: "via customer support" },
                { title: "Refund Guidance", desc: "via customer support" },
                { title: "Ticket Access Help", desc: "via customer support" },
                { title: "General Inquiries", desc: "via customer support" },
                { title: "Account Support", desc: "via customer support" }
              ].map((service, i) => (
                <motion.div 
                  key={i}
                  whileHover={{ y: -5 }}
                  className="bg-slate-900/80 p-8 rounded-2xl border border-slate-800 shadow-sm hover:shadow-md transition-all"
                >
                  <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white mb-6">
                    <CheckCircle2 size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{service.title}</h3>
                  <p className="text-slate-400 leading-relaxed">{service.desc}</p>
                </motion.div>
              ))}
            </div>
            
            <div className="mt-12 text-center text-slate-500 text-sm max-w-2xl mx-auto italic">
              * Our services are informational only. We do not guarantee specific outcomes from third-party ticketing platforms or venues.
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section id="how-it-works" className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeading>How It Works</SectionHeading>
            
            <div className="grid md:grid-cols-4 gap-8 relative">
              {/* Connector line for desktop */}
              <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-800 -translate-y-1/2 z-0"></div>
              
              {[
                { step: "01", title: "Contact Us", desc: "Reach out via phone, email, or our contact form with your specific inquiry." },
                { step: "02", title: "Consultation", desc: "A support specialist reviews your situation and identifies the correct path forward." },
                { step: "03", title: "Guidance", desc: "We provide clear, step-by-step instructions on how to resolve your issue." },
                { step: "04", title: "Resolution", desc: "You follow the provided guidance to complete your request with the official provider." }
              ].map((item, i) => (
                <div key={i} className="relative z-10 bg-slate-950 p-6 text-center">
                  <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto mb-6 shadow-lg">
                    {item.step}
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-slate-400 text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>

            <div className="mt-16 bg-slate-900 rounded-3xl p-8 md:p-12 text-center text-white">
              <h3 className="text-2xl font-bold mb-4">Important Clarification</h3>
              <p className="text-slate-300 max-w-3xl mx-auto text-lg">
                As an independent assistance service, we <strong>do not</strong> process payments for tickets, issue physical or digital tickets, or guarantee refunds from third-party sellers. Our role is to provide the professional guidance you need to handle these matters directly with official entities.
              </p>
            </div>
          </div>
        </section>

        {/* Why Choose Section */}
        <section className="py-20 bg-slate-900/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
              <div>
                <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-6">Why Choose Our Assistance?</h2>
                <p className="text-lg text-slate-400 mb-10">
                  We pride ourselves on transparency and professional support, ensuring you have a clear understanding of the ticketing landscape.
                </p>
                
                <div className="space-y-6">
                  {[
                    { title: "Transparent Communication", desc: "No hidden agendas or misleading claims. We are clear about our role as an independent provider." },
                    { title: "Clear Process", desc: "We follow a structured methodology to provide you with the most accurate information available." },
                    { title: "24/7 Availability", desc: "Our support team is available around the clock to assist with urgent event-related inquiries." },
                    { title: "Professional Support", desc: "Experienced specialists who understand the ticketing industry and its common challenges." }
                  ].map((item, i) => (
                    <div key={i} className="flex gap-4">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center mt-1">
                        <CheckCircle2 className="text-white w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-white">{item.title}</h4>
                        <p className="text-slate-400 text-sm">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="mt-12 lg:mt-0">
                <div className="relative rounded-3xl overflow-hidden shadow-2xl">
                  <img 
                    src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&q=80&w=1000" 
                    alt="Concert crowd" 
                    className="w-full h-[500px] object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
                  <div className="absolute bottom-8 left-8 right-8">
                    <div className="bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-2xl">
                      <p className="text-white font-medium italic">
                        "Our mission is to empower event-goers with the knowledge and support they need to navigate the complex world of ticketing."
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
              <SectionHeading subtitle="Fill out the form below or use our direct contact details. We do not request payment details or sensitive personal information.">
                Get in Touch
              </SectionHeading>
              
              <div className="grid md:grid-cols-5 gap-12">
                <div className="md:col-span-2 space-y-8">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center text-slate-300">
                        <Phone size={24} />
                      </div>
                      <div>
                        <h4 className="font-bold text-white">Phone Support</h4>
                        <a href="tel:+18334417141" className="text-slate-400 hover:text-blue-400 transition-colors">1-833-441-7141</a>
                        <p className="text-xs text-slate-500 mt-1">Toll-free, 24/7 availability</p>
                      </div>
                    </div>
                  

                </div>
                
                <div className="md:col-span-3">
                  {formStatus === 'success' ? (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center"
                    >
                      <div className="w-16 h-16 bg-green-900/30 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                        <CheckCircle2 size={32} />
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2">Message Sent</h3>
                      <p className="text-slate-400">Thank you for reaching out. A specialist will contact you shortly.</p>
                      <button 
                        onClick={() => setFormStatus('idle')}
                        className="mt-8 text-white font-bold underline"
                      >
                        Send another message
                      </button>
                    </motion.div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid sm:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-sm font-semibold text-slate-300 mb-2">Full Name</label>
                          <input 
                            required
                            type="text" 
                            placeholder="John Doe"
                            className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-800 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-slate-600"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold text-slate-300 mb-2">Email Address</label>
                          <input 
                            required
                            type="email" 
                            placeholder="john@example.com"
                            className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-800 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-slate-600"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-300 mb-2">Message</label>
                        <textarea 
                          required
                          rows={4}
                          placeholder="How can we assist you today?"
                          className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-800 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none placeholder:text-slate-600"
                        ></textarea>
                      </div>
                      <button 
                        disabled={formStatus === 'submitting'}
                        type="submit" 
                        className="w-full py-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all disabled:opacity-50"
                      >
                        {formStatus === 'submitting' ? 'Sending...' : 'Send Message'}
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Dedicated Disclaimer Section */}
        <section className="py-16 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-white/70 text-xs font-bold uppercase tracking-wider mb-8">
              <ShieldCheck size={14} />
              Legal Transparency
            </div>
            <h2 className="text-2xl font-bold mb-6">Independent Service Disclaimer</h2>
            <div className="max-w-3xl mx-auto space-y-4 text-slate-400 text-sm leading-relaxed">
              <p>
                TicketAssist is a professional, independent third-party assistance provider. We are not affiliated with, authorized by, endorsed by, or in any way officially connected with any ticketing companies (such as Ticketmaster, AXS, StubHub, etc.), event venues, sports teams, or concert organizers.
              </p>
              <p>
                All product and company names are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation with or endorsement by them.
              </p>
              <p>
                Our services are purely informational and advisory in nature. We do not sell tickets, process payments for event access, or have the authority to issue refunds on behalf of official ticketing platforms. Any actions taken based on our guidance are at the user's discretion.
              </p>
            </div>
          </div>
        </section>
          </>
        )}
      </main>

      {/* Footer Section */}
      <footer className="bg-slate-950 border-t border-slate-900 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <button onClick={() => setShowAbout(false)} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                  <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                    <ShieldCheck className="text-blue-600 w-5 h-5" />
                  </div>
                  <span className="font-bold text-xl tracking-tight text-white">TicketAssist</span>
                </button>
              </div>
              <p className="text-slate-400 max-w-sm mb-6">
                Providing professional, independent guidance for concert and event ticket inquiries since 2024.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-slate-500 hover:text-white transition-colors">Privacy Policy</a>
                <span className="text-slate-800">|</span>
                <a href="#" className="text-slate-500 hover:text-white transition-colors">Terms & Conditions</a>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold text-white mb-6 uppercase text-xs tracking-widest">About</h4>
              <ul className="space-y-4 text-sm text-slate-400">
                <li>
                  <button 
                    onClick={() => {
                      setShowAbout(true);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }} 
                    className="hover:text-white transition-colors"
                  >
                    About Us
                  </button>
                </li>
              </ul>
              <h4 className="font-bold text-white mt-8 mb-6 uppercase text-xs tracking-widest">Contact</h4>
              <ul className="space-y-4 text-sm text-slate-400">
                <li className="flex items-center gap-2">
                  <Phone size={14} />
                  <a href="tel:+18334417141" className="hover:text-white transition-colors">1-833-441-7141</a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold text-white mb-6 uppercase text-xs tracking-widest">Business Hours</h4>
              <ul className="space-y-4 text-sm text-slate-400">
                <li className="flex justify-between">
                  <span>Mon - Fri</span>
                  <span className="font-medium">24 Hours</span>
                </li>
                <li className="flex justify-between">
                  <span>Sat - Sun</span>
                  <span className="font-medium">24 Hours</span>
                </li>
                <li className="text-xs text-slate-600 italic mt-2">
                  Support specialists available around the clock.
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-900 pt-8 text-center text-slate-600 text-xs">
            <p>© {new Date().getFullYear()} TicketAssist Independent Support. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
